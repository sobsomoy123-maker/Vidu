// Verifies public/sfx/*.wav : duration, peak, clipping, RMS.   npm run check:sfx  (node scripts/check-sfx.mjs)
import {readFileSync, readdirSync} from 'node:fs';
import {dirname, join} from 'node:path';
import {fileURLToPath} from 'node:url';

const dir = join(dirname(fileURLToPath(import.meta.url)), '..', 'public', 'sfx');
const limits = {whoosh: [0.1, 0.8], default: [0.05, 0.5]};
let bad = 0;
for (const f of readdirSync(dir).filter((x) => x.endsWith('.wav')).sort()) {
  const b = readFileSync(join(dir, f));
  const sr = b.readUInt32LE(24);
  const n = (b.length - 44) / 2;
  let peak = 0, clip = 0, acc = 0, cnt = 0;
  const samples = [];
  for (let i = 0; i < n; i++) {
    const v = b.readInt16LE(44 + i * 2) / 32768;
    samples.push(v);
    peak = Math.max(peak, Math.abs(v));
    if (Math.abs(v) >= 0.999) clip++;
  }
  for (const v of samples) if (Math.abs(v) > peak * 0.05) { acc += v * v; cnt++; }
  const dur = n / sr;
  const rms = Math.sqrt(acc / cnt);
  const [lo, hi] = limits[f.replace('.wav', '')] ?? limits.default;
  const ok = dur >= lo && dur <= hi && clip === 0 && peak < 0.95;
  if (!ok) bad++;
  console.log(
    `${f.padEnd(12)} ${dur.toFixed(3)}s  peak ${(20 * Math.log10(peak)).toFixed(1)} dBFS  rms ${(20 * Math.log10(rms)).toFixed(1)} dBFS  clipped ${clip}  ${ok ? 'OK' : 'FAIL'}`,
  );
}
process.exit(bad ? 1 : 0);
