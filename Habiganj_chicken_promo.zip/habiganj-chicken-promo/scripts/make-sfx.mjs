// Synthesizes a small, soft UI/motion-graphics SFX kit -> public/sfx/*.wav  (npm run gen:sfx)
// pop · click · whoosh · chime · thud. Short, soft attack, fast decay, low-passed, tiny reverb, no clipping.
import {mkdirSync, writeFileSync} from 'node:fs';
import {dirname, join} from 'node:path';
import {fileURLToPath} from 'node:url';

const SR = 44100;
const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const outDir = join(root, 'public', 'sfx');
mkdirSync(outDir, {recursive: true});

// deterministic noise so the files are identical on every run
let seed = 20261022;
const rnd = () => {
  seed = (seed * 1664525 + 1013904223) >>> 0;
  return seed / 4294967296;
};
const noise = () => rnd() * 2 - 1;

const makeBuf = (sec) => new Float32Array(Math.round(sec * SR));

// RBJ biquad
const biquad = (type, f0, q = 0.707) => {
  const w = (2 * Math.PI * f0) / SR;
  const cos = Math.cos(w);
  const alpha = Math.sin(w) / (2 * q);
  let b0, b1, b2;
  const a0 = 1 + alpha;
  const a1 = -2 * cos;
  const a2 = 1 - alpha;
  if (type === 'lp') {
    b0 = (1 - cos) / 2;
    b1 = 1 - cos;
    b2 = (1 - cos) / 2;
  } else if (type === 'hp') {
    b0 = (1 + cos) / 2;
    b1 = -(1 + cos);
    b2 = (1 + cos) / 2;
  } else {
    // bandpass, constant 0 dB peak gain
    b0 = alpha;
    b1 = 0;
    b2 = -alpha;
  }
  let x1 = 0, x2 = 0, y1 = 0, y2 = 0;
  return (x) => {
    const y = (b0 * x + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2) / a0;
    x2 = x1; x1 = x; y2 = y1; y1 = y;
    return y;
  };
};

const lowpass = (buf, f, q = 0.707) => {
  const fl = biquad('lp', f, q);
  for (let i = 0; i < buf.length; i++) buf[i] = fl(buf[i]);
};

// very small reverb: convolution with a short decaying noise impulse
const smallReverb = (buf, mix = 0.12, tail = 0.06) => {
  const irLen = Math.round(tail * SR);
  const ir = new Float32Array(irLen);
  const lp = biquad('lp', 3200);
  for (let i = 0; i < irLen; i++) ir[i] = lp(noise()) * Math.exp((-6.9 * i) / irLen);
  ir[0] = 0;
  const out = new Float32Array(buf.length);
  const step = 3; // sparse taps keep this fast and soft
  for (let i = 0; i < buf.length; i++) {
    let acc = 0;
    for (let k = 1; k < irLen && k <= i; k += step) acc += buf[i - k] * ir[k];
    out[i] = buf[i] + acc * mix * step * 0.35;
  }
  buf.set(out);
};

const fade = (buf, inMs = 1, outMs = 12) => {
  const nIn = Math.round((inMs / 1000) * SR);
  const nOut = Math.round((outMs / 1000) * SR);
  for (let i = 0; i < nIn && i < buf.length; i++) buf[i] *= i / nIn;
  for (let i = 0; i < nOut && i < buf.length; i++) buf[buf.length - 1 - i] *= i / nOut;
};

// soft attack, exponential decay
const env = (t, attack, tau) => (t < attack ? Math.sin((t / attack) * Math.PI * 0.5) : Math.exp(-(t - attack) / tau));

const sounds = {};

// POP: sine with fast downward pitch glide + short envelope
sounds.pop = () => {
  const b = makeBuf(0.26);
  let phase = 0;
  for (let i = 0; i < b.length; i++) {
    const t = i / SR;
    const f = 150 + 560 * Math.exp(-t / 0.03);
    phase += (2 * Math.PI * f) / SR;
    b[i] = (Math.sin(phase) + 0.18 * Math.sin(2 * phase)) * env(t, 0.004, 0.05);
  }
  lowpass(b, 3800);
  smallReverb(b);
  fade(b, 1, 25);
  return b;
};

// CLICK: tiny high-passed noise burst + faint body
sounds.click = () => {
  const b = makeBuf(0.12);
  const hp = biquad('hp', 2600);
  let phase = 0;
  for (let i = 0; i < b.length; i++) {
    const t = i / SR;
    phase += (2 * Math.PI * 1250) / SR;
    b[i] = hp(noise()) * env(t, 0.0008, 0.0055) + 0.35 * Math.sin(phase) * env(t, 0.001, 0.012);
  }
  lowpass(b, 8500);
  smallReverb(b, 0.1, 0.04);
  fade(b, 0.5, 18);
  return b;
};

// WHOOSH: band-pass noise sweep with smooth fade in / out
sounds.whoosh = () => {
  const dur = 0.72;
  const b = makeBuf(dur);
  const bp = (f) => biquad('bp', f, 0.9);
  let fl = bp(400);
  let lastF = 400;
  for (let i = 0; i < b.length; i++) {
    const t = i / SR;
    const x = t / dur;
    const f = 380 + 2300 * Math.sin(Math.PI * Math.min(1, x * 1.15)) ** 1.4; // up then back down
    if (Math.abs(f - lastF) > 40 || i === 0) {
      fl = bp(f); // fresh filter state is fine for noise
      lastF = f;
    }
    const a = Math.sin(Math.PI * x) ** 2.2; // soft in, soft out
    b[i] = fl(noise()) * a;
  }
  lowpass(b, 5200);
  smallReverb(b, 0.1, 0.05);
  fade(b, 8, 40);
  return b;
};

// CHIME / PLUCK: soft inharmonic partials, short decay
sounds.chime = () => {
  const b = makeBuf(0.5);
  const partials = [
    [1, 1.0, 0.13],
    [2.01, 0.34, 0.085],
    [3.02, 0.16, 0.06],
    [4.17, 0.07, 0.04],
  ];
  const base = 988;
  for (let i = 0; i < b.length; i++) {
    const t = i / SR;
    let s = 0;
    for (const [m, a, tau] of partials) s += a * Math.sin(2 * Math.PI * base * m * t) * env(t, 0.003, tau);
    b[i] = s;
  }
  lowpass(b, 5200);
  smallReverb(b, 0.14, 0.07);
  fade(b, 1, 60);
  return b;
};

// THUD: very soft low thump for the hook (restrained)
sounds.thud = () => {
  const b = makeBuf(0.4);
  let phase = 0;
  const nlp = biquad('lp', 320);
  for (let i = 0; i < b.length; i++) {
    const t = i / SR;
    const f = 52 + 70 * Math.exp(-t / 0.05);
    phase += (2 * Math.PI * f) / SR;
    b[i] = Math.sin(phase) * env(t, 0.006, 0.09) + 0.12 * nlp(noise()) * env(t, 0.003, 0.03);
  }
  lowpass(b, 520);
  smallReverb(b, 0.08, 0.05);
  fade(b, 2, 70);
  return b;
};

// ---- level matching: same RMS over the audible part, peak hard-limited to -1.5 dBFS ----
const TARGET_RMS = 0.17;
const PEAK_CAP = 0.84;

const toWav = (buf) => {
  const data = Buffer.alloc(44 + buf.length * 2);
  data.write('RIFF', 0);
  data.writeUInt32LE(36 + buf.length * 2, 4);
  data.write('WAVE', 8);
  data.write('fmt ', 12);
  data.writeUInt32LE(16, 16);
  data.writeUInt16LE(1, 20);
  data.writeUInt16LE(1, 22);
  data.writeUInt32LE(SR, 24);
  data.writeUInt32LE(SR * 2, 28);
  data.writeUInt16LE(2, 32);
  data.writeUInt16LE(16, 34);
  data.write('data', 36);
  data.writeUInt32LE(buf.length * 2, 40);
  for (let i = 0; i < buf.length; i++) data.writeInt16LE(Math.round(Math.max(-1, Math.min(1, buf[i])) * 32767), 44 + i * 2);
  return data;
};

for (const [name, make] of Object.entries(sounds)) {
  const buf = make();
  let peak = 0;
  for (const v of buf) peak = Math.max(peak, Math.abs(v));
  // RMS over samples above 5% of peak (the audible body, not the silent tail)
  let acc = 0, n = 0;
  for (const v of buf) if (Math.abs(v) > peak * 0.05) { acc += v * v; n++; }
  const rms = Math.sqrt(acc / Math.max(1, n));
  let gain = TARGET_RMS / rms;
  if (peak * gain > PEAK_CAP) gain = PEAK_CAP / peak;
  for (let i = 0; i < buf.length; i++) buf[i] *= gain;
  writeFileSync(join(outDir, `${name}.wav`), toWav(buf));
}
console.log('SFX written to', outDir);
