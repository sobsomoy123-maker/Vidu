import React from 'react';
import {AbsoluteFill, Audio, Sequence, interpolate, staticFile, useCurrentFrame} from 'remotion';
import {SFX} from './choreo';
import {SFX_ENABLED, WIDTH, HEIGHT} from './config';
import {BgMesh, CL, Grade, Grain, SceneProvider, Vignette} from './components/kit';
import {PreviewAudio} from './components/PreviewAudio';
import {Click} from './scenes/Click';
import {Contact} from './scenes/Contact';
import {Cuts} from './scenes/Cuts';
import {Delivery} from './scenes/Delivery';
import {Hook} from './scenes/Hook';
import {Offal} from './scenes/Offal';
import {Recap} from './scenes/Recap';
import {SCENES, type Dir} from './timeline';
import {theme} from './theme';

const COMPONENTS = {hook: Hook, click: Click, cuts: Cuts, offal: Offal, delivery: Delivery, contact: Contact, recap: Recap};

const vec = (d: Dir) => ({left: [-1, 0], right: [1, 0], up: [0, -1], down: [0, 1]}[d]);

// push transition: incoming scene slides in from `from`; outgoing slides the opposite way (fast, eased, soft blur)
const Push: React.FC<{from: Dir; dur: number; last: boolean; children: React.ReactNode}> = ({from, dur, last, children}) => {
  const f = useCurrentFrame();
  const P = theme.motion.pushFrames;
  const [vx, vy] = vec(from);
  const inP = interpolate(f, [0, P], [0, 1], {easing: theme.ease.out, ...CL});
  const outP = last ? 0 : interpolate(f, [dur - P, dur], [0, 1], {easing: theme.ease.in, ...CL});
  const tx = vx * WIDTH * 0.55 * (1 - inP) - vx * WIDTH * 0.35 * outP;
  const ty = vy * HEIGHT * 0.55 * (1 - inP) - vy * HEIGHT * 0.35 * outP;
  const blur = 10 * (1 - inP) + 8 * outP;
  return (
    <AbsoluteFill style={{transform: `translate(${tx}px, ${ty}px)`, opacity: Math.min(inP * 2.5, 1) * (1 - outP), filter: blur > 0.3 ? `blur(${blur}px)` : undefined}}>
      {children}
    </AbsoluteFill>
  );
};

export const Main: React.FC = () => (
  <AbsoluteFill style={{background: theme.colors.bg}}>
    <BgMesh />
    {SCENES.map((s, i) => {
      const Scene = COMPONENTS[s.id];
      return (
        <Sequence key={s.id} from={s.start} durationInFrames={s.dur} layout="none">
          <SceneProvider value={{start: s.start}}>
            <Sequence from={0} durationInFrames={s.dur} layout="none">
              <Push from={s.from} dur={s.dur} last={i === SCENES.length - 1}>
                <Scene />
              </Push>
            </Sequence>
          </SceneProvider>
        </Sequence>
      );
    })}
    <Grade />
    <Grain />
    <Vignette />

    {SFX_ENABLED &&
      SFX.map((s, i) => (
        <Sequence key={i} from={s.frame} durationInFrames={45} layout="none">
          <Audio src={staticFile(`sfx/${s.name}.wav`)} volume={s.vol} playbackRate={s.rate ?? 1} />
        </Sequence>
      ))}
    <PreviewAudio />
  </AbsoluteFill>
);
