import React from 'react';
import {AbsoluteFill, interpolate} from 'remotion';
import {C} from '../choreo';
import {CL, FONT, Photo, Pill, Pop, Words, useSince, useSp} from '../components/kit';
import {theme, withAlpha} from '../theme';

// Scene 1 - HOOK (cue 1). Style: Kinetic Typography + brand reveal.
export const Hook: React.FC = () => {
  const since = useSince();
  const sp = useSp();

  const underline = interpolate(since(C.hook.chicken + 12), [0, 18], [0, 100], {easing: theme.ease.out, ...CL});
  const slam = sp(since(C.hook.fresh), theme.spring.bouncy);

  return (
    <AbsoluteFill style={{fontFamily: FONT}}>
      {/* soft sun behind the logo */}
      <Pop
        at={0}
        y={0}
        s={0.6}
        style={{
          position: 'absolute',
          left: 990,
          top: 100,
          width: 860,
          height: 860,
          borderRadius: '50%',
          background: `radial-gradient(circle, ${withAlpha(theme.colors.accent, 0.34)}, ${withAlpha(theme.colors.accent, 0.12)} 62%, transparent 70%)`,
        }}
      />

      {/* LEFT: kinetic type */}
      <div style={{position: 'absolute', left: 90, top: 178, width: 960}}>
        <Pop at={C.hook.pill} y={30} cfg={theme.spring.snappy} style={{display: 'inline-block'}}>
          <Pill text="হবিগঞ্জ পৌরসভায়" size={56} padX={40} padY={8} />
        </Pop>

        <div style={{marginTop: 20}}>
          <Words words={['Fresh']} at={C.hook.fresh} size={236} lh={1.08} color={theme.colors.text} />
          <div style={{position: 'relative', display: 'inline-block'}}>
            <div style={{transform: `scale(${1.28 - 0.28 * slam})`, transformOrigin: '0% 70%'}}>
              <Words words={['Chicken']} at={C.hook.chicken} size={236} lh={1.08} color={theme.colors.primary} />
            </div>
            <div
              style={{
                position: 'absolute',
                left: 6,
                bottom: 14,
                height: 16,
                width: `${underline}%`,
                maxWidth: 846,
                borderRadius: 10,
                background: theme.colors.accent,
              }}
            />
          </div>
        </div>

        <div style={{marginTop: 30}}>
          <Words
            words={['কার্যক্রম', {t: 'শুরু', sweep: true}]}
            at={C.hook.sub}
            per={6}
            size={84}
            weight={600}
            color={theme.colors.text}
            gap={26}
          />
        </div>
      </div>

      {/* RIGHT: brand card (the logo is shown exactly as supplied, never redrawn) */}
      <Photo
        src="images/logo.jpg"
        x={1120}
        y={240}
        w={600}
        h={600}
        at={C.hook.logo}
        radius={44}
        zoom={0.05}
        cfg={theme.spring.bouncy}
        from={{y: 30, s: 0.7}}
        rot={0}
      />
      <Photo
        src="images/breast-plate.png"
        x={1500}
        y={690}
        w={290}
        h={290}
        at={C.hook.disc}
        radius={145}
        border={10}
        zoom={0.1}
        reverse
        cfg={theme.spring.bouncy}
        from={{y: 40, s: 0.6}}
        pos="55% 48%"
        float={6}
      />
    </AbsoluteFill>
  );
};
