import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';
import {C} from '../choreo';
import {CL, FONT, Photo, Pill, Pop, Tick, Words, useSince, useSp} from '../components/kit';
import {theme, withAlpha} from '../theme';

// Scene 7 - recap + brand close (cue 9). Style: Checklist Recap Grid -> clean brand ending.
const CARDS = [
  {t: 'স্বাদ', at: () => C.recap.taste},
  {t: 'সতেজতা', at: () => C.recap.fresh},
  {t: 'সুবিধা', at: () => C.recap.easy},
];

export const Recap: React.FC = () => {
  const since = useSince();
  const sp = useSp();
  const frame = useCurrentFrame();

  // grid fades back as the brand close takes over
  const close = interpolate(since(C.recap.final), [0, 16], [0, 1], {easing: theme.ease.inOut, ...CL});
  const breathe = 1 + Math.sin(frame / 22) * 0.012;

  return (
    <AbsoluteFill style={{fontFamily: FONT}}>
      {/* recap grid: three tick cards */}
      <div style={{position: 'absolute', left: 0, top: 0, right: 0, bottom: 0, opacity: 1 - close, transform: `translateY(${-40 * close}px) scale(${1 - 0.05 * close})`}}>
        <Pop at={C.recap.taste - 8} y={20} cfg={theme.spring.snappy} style={{position: 'absolute', left: 0, right: 0, top: 150, textAlign: 'center'}}>
          <Pill text="Ammu's Kitchen · Fresh Chicken" size={44} padX={38} />
        </Pop>
        {CARDS.map((c, i) => {
          const at = c.at();
          const tp = sp(since(at + 8), theme.spring.smooth);
          return (
            <Pop
              key={i}
              at={at}
              y={50}
              s={0.9}
              cfg={theme.spring.bouncy}
              style={{position: 'absolute', left: 120 + i * 580, top: 290, width: 540, height: 500}}
            >
              <div
                style={{
                  width: 540,
                  height: 500,
                  borderRadius: theme.radius.card,
                  background: withAlpha(theme.colors.surface, 0.86),
                  border: `2px solid ${withAlpha(theme.colors.surface, 0.95)}`,
                  boxShadow: theme.shadow.card,
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: 30,
                  boxSizing: 'border-box',
                }}
              >
                <div style={{width: 150, height: 150}}>
                  <Tick size={150} p={tp} bg={i === 1 ? theme.colors.primary : theme.colors.accent} color={i === 1 ? theme.colors.onPrimary : theme.colors.text} />
                </div>
                <div style={{fontSize: 108, fontWeight: 700, lineHeight: 1.25, color: theme.colors.text, letterSpacing: 0}}>{c.t}</div>
              </div>
            </Pop>
          );
        })}
        <Pop at={C.recap.together} y={30} cfg={theme.spring.snappy} style={{position: 'absolute', left: 0, right: 0, top: 850, textAlign: 'center'}}>
          <div style={{fontSize: 84, fontWeight: 700, lineHeight: 1.3, color: theme.colors.text}}>
            সব <span style={{color: theme.colors.primary}}>একসাথে</span>
          </div>
        </Pop>
      </div>

      {/* brand close */}
      <div style={{position: 'absolute', left: 0, top: 0, right: 0, bottom: 0, opacity: close}}>
        <Photo
          src="images/logo.jpg"
          x={560}
          y={250}
          w={560}
          h={560}
          at={C.recap.final}
          radius={48}
          zoom={0.05}
          cfg={theme.spring.bouncy}
          from={{y: 30, s: 0.7}}
          float={3}
        />
        <Pop at={C.recap.waiting} y={30} style={{position: 'absolute', left: 1150, top: 390, transform: `scale(${breathe})`}}>
          <Words
            words={['আপনার', 'অর্ডারের']}
            at={C.recap.final}
            per={5}
            size={84}
            weight={600}
            lh={1.3}
            gap={24}
            style={{width: 700}}
          />
        </Pop>
        <div style={{position: 'absolute', left: 1150, top: 490, width: 700}}>
          <Words
            words={[{t: 'অপেক্ষায়', sweep: true}, {t: 'আমরা', color: theme.colors.primary}]}
            at={C.recap.waiting}
            per={7}
            size={132}
            lh={1.2}
            gap={30}
          />
        </div>
        <Pop at={C.recap.we + 12} y={20} cfg={theme.spring.snappy} style={{position: 'absolute', left: 1150, top: 700}}>
          <Pill text="হবিগঞ্জ পৌরসভা · home delivery" size={40} padX={34} bg={theme.colors.primary} color={theme.colors.onPrimary} />
        </Pop>
      </div>
    </AbsoluteFill>
  );
};
