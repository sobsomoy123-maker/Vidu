import React from 'react';
import {AbsoluteFill, Img, interpolate, staticFile, useCurrentFrame} from 'remotion';
import {C} from '../choreo';
import {CL, CursorIcon, FONT, Pill, Pop, Words, useSince, useSp} from '../components/kit';
import {theme, withAlpha} from '../theme';

// Scene 2 - "এক ক্লিকেই" (cue 2). Style: Glossy UI Mockup (browser window + cursor click).
const WIN = {x: 800, y: 170, w: 1030, h: 740};
const BTN = {w: 360, h: 70, x: WIN.w - 28 - 360, y: 594}; // inside window, relative to window

export const Click: React.FC = () => {
  const since = useSince();
  const sp = useSp();
  const frame = useCurrentFrame();

  // click moment + state swap
  const tClick = since(C.click.click);
  const press = interpolate(tClick, [0, 4, 10], [1, 0.94, 1], {easing: theme.ease.inOut, ...CL});
  const ripple = interpolate(tClick, [0, 20], [0, 1], {easing: theme.ease.out, ...CL});

  // cursor path: arrives from bottom-right, lands on the button at the click moment
  const cursorIn = interpolate(tClick, [-30, 0], [0, 1], {easing: theme.ease.inOut, ...CL});
  const cursorOut = interpolate(since(C.click.reach), [0, 14], [0, 1], {easing: theme.ease.in, ...CL});
  const btnCx = WIN.x + BTN.x + BTN.w * 0.62;
  const btnCy = WIN.y + BTN.y + BTN.h * 0.55;
  const cx = interpolate(cursorIn, [0, 1], [btnCx + 260, btnCx]) + cursorOut * 40;
  const cy = interpolate(cursorIn, [0, 1], [btnCy + 330, btnCy]) + cursorOut * 70;
  const cursorO = interpolate(cursorIn, [0, 0.3], [0, 1], CL) * (1 - cursorOut);

  // board -> boneless detail swap
  const swap = interpolate(since(C.click.boneless), [0, 14], [0, 1], {easing: theme.ease.inOut, ...CL});
  const detail = sp(since(C.click.boneless + 4), theme.spring.smooth);
  const bob = Math.sin(frame / 34) * 4;

  return (
    <AbsoluteFill style={{fontFamily: FONT}}>
      {/* LEFT: type */}
      <div style={{position: 'absolute', left: 90, top: 258, width: 680}}>
        <Pop at={C.click.cut} y={26} cfg={theme.spring.snappy} style={{display: 'inline-block'}}>
          <Pill text="Chicken cut" size={46} padX={36} />
        </Pop>
        <div style={{marginTop: 26}}>
          <Words words={['এক', {t: 'ক্লিকেই', sweep: true}]} at={C.click.one} per={6} size={168} lh={1.22} gap={34} />
        </div>
        <div style={{marginTop: 8}}>
          <Words words={['হাতের', 'নাগালে']} at={C.click.reach} per={5} size={112} weight={600} lh={1.28} gap={28} color={theme.colors.textDim} />
        </div>
      </div>

      {/* RIGHT: browser window */}
      <Pop
        at={C.click.window}
        y={60}
        s={0.9}
        style={{position: 'absolute', left: WIN.x, top: WIN.y + bob, width: WIN.w, height: WIN.h}}
      >
        <div
          style={{
            width: WIN.w,
            height: WIN.h,
            borderRadius: 40,
            background: theme.colors.surface,
            boxShadow: theme.shadow.card,
            overflow: 'hidden',
            position: 'relative',
            border: `2px solid ${theme.colors.hairline}`,
            boxSizing: 'border-box',
          }}
        >
          {/* chrome */}
          <div style={{height: 64, background: theme.colors.bgAlt, display: 'flex', alignItems: 'center', gap: 12, padding: '0 26px'}}>
            {[0, 1, 2].map((i) => (
              <div key={i} style={{width: 16, height: 16, borderRadius: 8, background: withAlpha(theme.colors.text, 0.22)}} />
            ))}
            <div
              style={{
                marginLeft: 22,
                height: 38,
                width: 380,
                borderRadius: 19,
                background: theme.colors.surface,
                display: 'flex',
                alignItems: 'center',
                padding: '0 22px',
                fontFamily: FONT,
                fontSize: 24,
                fontWeight: 500,
                color: theme.colors.textDim,
              }}
            >
              Fresh Chicken
            </div>
          </div>

          {/* state A: cut board + order button */}
          <div style={{position: 'absolute', left: 0, top: 64, right: 0, bottom: 0, opacity: 1 - swap, transform: `translateX(${-70 * swap}px)`}}>
            <Img
              src={staticFile('images/cuts-board.jpg')}
              style={{position: 'absolute', left: 24, top: 24, width: 982, height: 470, borderRadius: 24, objectFit: 'cover', boxShadow: theme.shadow.soft}}
            />
            <div
              style={{
                position: 'absolute',
                left: 28,
                top: BTN.y - 64,
                fontFamily: FONT,
                fontSize: 34,
                fontWeight: 600,
                color: theme.colors.textDim,
                lineHeight: `${BTN.h}px`,
              }}
            >
              Chicken cut
            </div>
            <div
              style={{
                position: 'absolute',
                left: BTN.x,
                top: BTN.y - 64,
                width: BTN.w,
                height: BTN.h,
                borderRadius: BTN.h / 2,
                background: theme.colors.primary,
                color: theme.colors.onPrimary,
                fontFamily: FONT,
                fontWeight: 700,
                fontSize: 36,
                lineHeight: `${BTN.h}px`,
                textAlign: 'center',
                transform: `scale(${press})`,
                boxShadow: `0 14px 30px -10px ${theme.colors.glow}`,
              }}
            >
              অর্ডার করুন
            </div>
            {/* click ripple */}
            <div
              style={{
                position: 'absolute',
                left: BTN.x + BTN.w * 0.62 - 90,
                top: BTN.y - 64 + BTN.h * 0.55 - 90,
                width: 180,
                height: 180,
                borderRadius: 90,
                border: `5px solid ${theme.colors.accent}`,
                opacity: tClick > 0 ? 1 - ripple : 0,
                transform: `scale(${0.2 + ripple * 1.1})`,
              }}
            />
          </div>

          {/* state B: boneless detail */}
          <div style={{position: 'absolute', left: 0, top: 64, right: 0, bottom: 0, opacity: swap, transform: `translateX(${(1 - swap) * 90}px)`}}>
            <Img
              src={staticFile('images/boneless-cubes.png')}
              style={{
                position: 'absolute',
                left: 30,
                top: 36,
                width: 540,
                height: 355,
                borderRadius: 28,
                objectFit: 'cover',
                boxShadow: theme.shadow.soft,
                transform: `scale(${1 + 0.04 * detail})`,
              }}
            />
            <div style={{position: 'absolute', left: 620, top: 66, width: 380}}>
              <Pill text="Super fresh" size={36} bg={theme.colors.accent} color={theme.colors.text} padX={28} />
              <div style={{fontFamily: FONT, fontSize: 80, fontWeight: 700, lineHeight: 1.12, color: theme.colors.text, marginTop: 16, letterSpacing: 0}}>
                boneless
              </div>
              <div style={{fontFamily: FONT, fontSize: 80, fontWeight: 700, lineHeight: 1.12, color: theme.colors.primary, letterSpacing: 0}}>
                cut
              </div>
            </div>
          </div>
        </div>
      </Pop>

      {/* cursor */}
      <div style={{position: 'absolute', left: cx, top: cy, opacity: cursorO, transform: `scale(${press})`, transformOrigin: '0 0'}}>
        <CursorIcon size={64} />
      </div>
    </AbsoluteFill>
  );
};
