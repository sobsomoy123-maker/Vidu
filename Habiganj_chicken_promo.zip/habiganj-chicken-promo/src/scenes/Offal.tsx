import React from 'react';
import {AbsoluteFill, interpolate} from 'remotion';
import {C} from '../choreo';
import {CL, FONT, Photo, Pill, Pop, Tick, useSince, useSp} from '../components/kit';
import {theme, withAlpha} from '../theme';

// Scene 4 - giblets + clean processing (cue 5). Style: Glass cards + photo with pins.
const PHOTO = {x: 930, y: 170, w: 900, h: 580}; // offal-bowls.png (1078x694)

const Pin: React.FC<{at: number; px: number; py: number; label: string}> = ({at, px, py, label}) => {
  const since = useSince();
  const sp = useSp();
  const p = sp(since(at), theme.spring.bouncy);
  const pulse = interpolate(since(at + 6), [0, 34], [0, 1], {easing: theme.ease.out, ...CL});
  const x = PHOTO.x + px * PHOTO.w;
  const y = PHOTO.y + py * PHOTO.h;
  return (
    <>
      <div
        style={{
          position: 'absolute',
          left: x - 40,
          top: y - 40,
          width: 80,
          height: 80,
          borderRadius: 40,
          border: `5px solid ${theme.colors.accent}`,
          opacity: pulse > 0 && pulse < 1 ? 1 - pulse : 0,
          transform: `scale(${0.3 + pulse * 1.3})`,
        }}
      />
      <div
        style={{
          position: 'absolute',
          left: x - 17,
          top: y - 17,
          width: 34,
          height: 34,
          borderRadius: 17,
          background: theme.colors.accent,
          border: `6px solid ${theme.colors.surface}`,
          boxSizing: 'border-box',
          boxShadow: theme.shadow.soft,
          opacity: Math.min(1, p * 2),
          transform: `scale(${p})`,
        }}
      />
      <div
        style={{
          position: 'absolute',
          left: x,
          top: y - 98,
          transform: `translate(-50%, ${(1 - p) * 16}px) scale(${0.85 + 0.15 * p})`,
          opacity: Math.min(1, p * 1.6),
        }}
      >
        <Pill text={label} size={46} bg={theme.colors.surface} color={theme.colors.text} padX={30} padY={4} style={{boxShadow: theme.shadow.soft}} />
      </div>
    </>
  );
};

const Row: React.FC<{
  at: number;
  y: number;
  title: string;
  sub?: string;
  tag?: string;
  tick?: boolean;
  size?: number;
}> = ({at, y, title, sub, tag, tick, size = 54}) => {
  const since = useSince();
  const sp = useSp();
  const tp = sp(since(at + 6), theme.spring.smooth);
  return (
    <Pop at={at} y={34} x={-60} style={{position: 'absolute', left: 90, top: y, width: 700, height: 128}}>
      <div
        style={{
          height: 128,
          borderRadius: 32,
          display: 'flex',
          alignItems: 'center',
          gap: 24,
          padding: '0 28px',
          boxSizing: 'border-box',
          background: withAlpha(theme.colors.surface, 0.78),
          border: `2px solid ${withAlpha(theme.colors.surface, 0.95)}`,
          boxShadow: theme.shadow.soft,
        }}
      >
        <div style={{width: 64, height: 64, flexShrink: 0}}>
          {tick ? (
            <Tick size={64} p={tp} />
          ) : (
            <div style={{width: 64, height: 64, borderRadius: 32, background: withAlpha(theme.colors.accent, 0.3), display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
              <div style={{width: 26, height: 26, borderRadius: 8, background: theme.colors.accent, transform: `scale(${tp})`}} />
            </div>
          )}
        </div>
        <div style={{flex: 1, minWidth: 0}}>
          <div style={{fontSize: size, fontWeight: 700, lineHeight: 1.22, color: theme.colors.text, whiteSpace: 'nowrap'}}>{title}</div>
          {sub ? <div style={{fontSize: 30, fontWeight: 500, lineHeight: 1.3, color: theme.colors.textDim, whiteSpace: 'nowrap'}}>{sub}</div> : null}
        </div>
        {tag ? <Pill text={tag} size={28} bg={theme.colors.accent} color={theme.colors.text} padX={20} padY={2} weight={600} /> : null}
      </div>
    </Pop>
  );
};

export const Offal: React.FC = () => {
  return (
    <AbsoluteFill style={{fontFamily: FONT}}>
      {/* left column */}
      <Pop at={C.offal.kicker} y={24} cfg={theme.spring.snappy} style={{position: 'absolute', left: 90, top: 150}}>
        <Pill text="পরিষ্কার পরিচ্ছন্ন" size={46} padX={36} />
      </Pop>
      <Row at={C.offal.gizzard} y={246} title="গিলা" tag="আলাদা প্যাকেটে" />
      <Row at={C.offal.liver} y={396} title="কলিজা" tag="আলাদা প্যাকেটে" />
      <Row at={C.offal.processed} y={546} title="process করা Chicken" sub="পরিচ্ছন্নভাবে" tick size={50} />
      <Row at={C.offal.ready} y={696} title="ready to cook cut" tick size={50} />

      {/* right: bowls photo with pins (gizzards = top bowl, liver = bottom-right bowl) */}
      <Photo
        src="images/offal-bowls.png"
        x={PHOTO.x}
        y={PHOTO.y}
        w={PHOTO.w}
        h={PHOTO.h}
        at={C.offal.kicker + 2}
        radius={40}
        zoom={0.07}
        cfg={theme.spring.smooth}
        from={{x: 80, y: 20, s: 0.94}}
        float={3}
      />
      <Pin at={C.offal.gizzard + 4} px={0.66} py={0.3} label="গিলা" />
      <Pin at={C.offal.liver + 4} px={0.8} py={0.72} label="কলিজা" />

      {/* ready-to-cook inset */}
      <Photo
        src="images/boneless-cubes.png"
        x={1400}
        y={706}
        w={420}
        h={278}
        at={C.offal.ready}
        radius={32}
        border={8}
        zoom={0.1}
        reverse
        from={{y: 60, x: 40, s: 0.9}}
        cfg={theme.spring.bouncy}
        float={5}
      />
    </AbsoluteFill>
  );
};
