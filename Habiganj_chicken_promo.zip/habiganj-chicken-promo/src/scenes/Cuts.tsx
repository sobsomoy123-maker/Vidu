import React from 'react';
import {AbsoluteFill, Img, interpolate, staticFile, useCurrentFrame} from 'remotion';
import {C} from '../choreo';
import {CL, FONT, Pop, Tick, useSince, useSp} from '../components/kit';
import {toBn} from '../timing';
import {theme, withAlpha} from '../theme';

// Scene 3 - the cuts (cues 3 + 4). Style: Board spotlight + numbered list (carousel-style 01/04 counter).
const BOARD = {x: 90, y: 256, w: 1040, h: 568, srcW: 1070, srcH: 584};
const K = BOARD.w / BOARD.srcW;

// focus windows in the SOURCE image's pixel space (item photo + its Bengali label)
const RECTS = [
  {x: 70, y: 112, w: 475, h: 216}, // boneless breast + boneless thigh
  {x: 295, y: 328, w: 240, h: 230}, // leg piece
  {x: 50, y: 328, w: 235, h: 230}, // thigh
  {x: 540, y: 108, w: 240, h: 220}, // wings
];

const ITEMS = [
  {title: 'Boneless cut', sub: 'Super fresh'},
  {title: 'Leg piece', sub: 'juicy · roast ও grill-এর জন্য'},
  {title: 'Thigh piece', sub: 'soft · সুস্বাদু রান্নার জন্য'},
  {title: 'Chicken wings', sub: 'crispy · snacks-এর জন্য'},
];

const lerp = (a: number, b: number, t: number) => a + (b - a) * t;

export const Cuts: React.FC = () => {
  const since = useSince();
  const sp = useSp();
  const frame = useCurrentFrame();

  const T = [C.cuts.boneless, C.cuts.leg, C.cuts.thigh, C.cuts.wings];
  let idx = 0;
  T.forEach((t, i) => {
    if (since(t) >= 0) idx = i;
  });

  // spotlight rect (moves between targets with a smooth ease)
  const prog = idx === 0 ? 1 : interpolate(since(T[idx]), [0, 16], [0, 1], {easing: theme.ease.inOut, ...CL});
  const a = RECTS[Math.max(0, idx - 1)];
  const b = RECTS[idx];
  const r = idx === 0 ? b : {x: lerp(a.x, b.x, prog), y: lerp(a.y, b.y, prog), w: lerp(a.w, b.w, prog), h: lerp(a.h, b.h, prog)};
  const ringO = interpolate(since(T[0]), [0, 12], [0, 1], CL);
  const kb = interpolate(frame, [0, 300], [1, 1.035], {easing: theme.ease.inOut, ...CL});

  return (
    <AbsoluteFill style={{fontFamily: FONT}}>
      {/* LEFT: the cut board with a moving spotlight */}
      <Pop at={C.cuts.start} y={50} s={0.94} style={{position: 'absolute', left: BOARD.x, top: BOARD.y, width: BOARD.w, height: BOARD.h}}>
        <div
          style={{
            width: BOARD.w,
            height: BOARD.h,
            borderRadius: theme.radius.card,
            overflow: 'hidden',
            position: 'relative',
            boxShadow: theme.shadow.card,
            background: theme.colors.surface,
          }}
        >
          <div style={{position: 'absolute', inset: 0, transform: `scale(${kb})`, transformOrigin: '50% 50%'}}>
            <Img src={staticFile('images/cuts-board.jpg')} style={{width: '100%', height: '100%', objectFit: 'cover'}} />
            <div
              style={{
                position: 'absolute',
                left: r.x * K,
                top: r.y * K,
                width: r.w * K,
                height: r.h * K,
                borderRadius: 24,
                border: `6px solid ${theme.colors.accent}`,
                boxShadow: `0 0 0 2400px ${withAlpha('#3B1F14', 0.5 * ringO)}, 0 0 36px ${withAlpha(theme.colors.accent, 0.7 * ringO)}`,
                opacity: ringO,
                boxSizing: 'border-box',
              }}
            />
          </div>
        </div>
      </Pop>

      {/* RIGHT: header + numbered list */}
      <Pop at={C.cuts.start + 4} y={24} cfg={theme.spring.snappy} style={{position: 'absolute', left: 1180, top: 168, width: 650}}>
        <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'baseline'}}>
          <div style={{fontSize: 46, fontWeight: 700, color: theme.colors.text, lineHeight: 1.3}}>Chicken cuts</div>
          <div style={{fontSize: 46, fontWeight: 600, color: theme.colors.textDim, lineHeight: 1.3}}>
            {toBn(`0${idx + 1}`)} / {toBn('04')}
          </div>
        </div>
      </Pop>

      {ITEMS.map((it, i) => {
        const tNow = since(T[i]);
        const tNext = i < ITEMS.length - 1 ? since(T[i + 1]) : -1;
        const act = sp(tNow, theme.spring.snappy) * (1 - sp(tNext, theme.spring.snappy)); // 1 while active
        const past = sp(tNext, theme.spring.snappy); // 1 once the next one took over
        const tickP = sp(tNext - 4, theme.spring.smooth);
        const top = 250 + i * 160;
        return (
          <Pop
            key={i}
            at={C.cuts.start + 8 + i * 5}
            y={36}
            x={50}
            style={{position: 'absolute', left: 1180, top, width: 650, height: 140}}
          >
            <div
              style={{
                height: 140,
                borderRadius: 30,
                display: 'flex',
                alignItems: 'center',
                gap: 22,
                padding: '0 26px',
                boxSizing: 'border-box',
                background: withAlpha(theme.colors.surface, 0.55 + 0.45 * act),
                border: `3px solid ${act > 0.5 ? theme.colors.accent : theme.colors.hairline}`,
                boxShadow: act > 0.05 ? theme.shadow.soft : 'none',
                opacity: 0.62 + 0.38 * Math.max(act, past * 0.3),
                transform: `translateX(${-14 * act}px) scale(${1 + 0.02 * act})`,
              }}
            >
              <div style={{width: 76, height: 76, flexShrink: 0, position: 'relative'}}>
                <div
                  style={{
                    position: 'absolute',
                    inset: 0,
                    borderRadius: 38,
                    background: act > 0.5 ? theme.colors.primary : withAlpha(theme.colors.text, 0.08),
                    color: act > 0.5 ? theme.colors.onPrimary : theme.colors.textDim,
                    fontSize: 42,
                    fontWeight: 700,
                    lineHeight: '76px',
                    textAlign: 'center',
                    opacity: 1 - Math.min(1, tickP * 2),
                  }}
                >
                  {toBn(String(i + 1))}
                </div>
                <div style={{position: 'absolute', inset: 14, opacity: Math.min(1, tickP * 2)}}>
                  <Tick size={48} p={tickP} />
                </div>
              </div>
              <div style={{minWidth: 0}}>
                <div style={{fontSize: 54, fontWeight: 700, lineHeight: 1.15, color: theme.colors.text, whiteSpace: 'nowrap'}}>{it.title}</div>
                <div style={{fontSize: 30, fontWeight: 500, lineHeight: 1.35, color: theme.colors.textDim, whiteSpace: 'nowrap'}}>{it.sub}</div>
              </div>
            </div>
          </Pop>
        );
      })}
    </AbsoluteFill>
  );
};
