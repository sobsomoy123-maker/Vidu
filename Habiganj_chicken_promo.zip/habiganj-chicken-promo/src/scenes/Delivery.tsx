import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';
import {C} from '../choreo';
import {CL, FONT, Photo, Pill, Pop, Words, useSince} from '../components/kit';
import {theme, withAlpha} from '../theme';

// Scene 5 - fast home delivery + "don't wait, order today" (cue 6). Style: Statement + delivery visual with speed lines.
export const Delivery: React.FC = () => {
  const since = useSince();
  const frame = useCurrentFrame();

  // speed lines streak left->right behind the photo while "দ্রুত" lands
  const streak = interpolate(since(C.delivery.fast - 4), [0, 22], [0, 1], {easing: theme.ease.out, ...CL});
  const streakFade = interpolate(since(C.delivery.fast + 18), [0, 20], [1, 0], CL);

  // "late?" line swaps in: left block rises out, then the order lines come
  const lateOut = C.delivery.today - 2;

  return (
    <AbsoluteFill style={{fontFamily: FONT}}>
      {/* speed lines */}
      {[0, 1, 2, 3, 4].map((i) => {
        const y = 250 + i * 118 + (i % 2) * 26;
        const len = (420 + (i % 3) * 170) * streak;
        return (
          <div
            key={i}
            style={{
              position: 'absolute',
              left: 760 - len * 0.2,
              top: y,
              width: len,
              height: 10,
              borderRadius: 5,
              background: `linear-gradient(90deg, transparent, ${withAlpha(theme.colors.accent, 0.55)})`,
              opacity: streak * streakFade,
            }}
          />
        );
      })}

      {/* LEFT text */}
      <div style={{position: 'absolute', left: 90, top: 120, width: 800}}>
        <Pop at={C.delivery.fast} y={26} cfg={theme.spring.snappy} style={{display: 'inline-block'}}>
          <Pill text="দ্রুত" size={64} padX={46} padY={6} bg={theme.colors.primary} color={theme.colors.onPrimary} />
        </Pop>
        <div style={{marginTop: 22}}>
          <Words words={['home', {t: 'delivery', sweep: true}]} at={C.delivery.home} per={6} size={150} lh={1.1} gap={30} />
        </div>
        <div style={{marginTop: 22}}>
          <Words words={['আপনার', 'সুবিধার', 'জন্য']} at={C.delivery.home + 12} per={5} size={64} weight={600} lh={1.3} gap={20} color={theme.colors.textDim} />
        </div>
      </div>

      {/* bottom strip: "তাহলে আর দেরি কেন?" -> "আজই অর্ডার করতে inbox করুন" */}
      <div style={{position: 'absolute', left: 90, top: 790, width: 1740, height: 190}}>
        <Words
          words={['তাহলে', 'আর', 'দেরি', {t: 'কেন?', color: theme.colors.primary}]}
          at={C.delivery.late}
          out={lateOut}
          per={5}
          size={112}
          lh={1.25}
          gap={34}
        />
      </div>
      <div style={{position: 'absolute', left: 90, top: 790, width: 1740, height: 190}}>
        <Words
          words={[{t: 'আজই', sweep: true}, 'অর্ডার', 'করতে', {t: 'inbox', color: theme.colors.primary}, 'করুন']}
          at={C.delivery.today}
          per={5}
          size={104}
          lh={1.3}
          gap={30}
        />
      </div>

      {/* RIGHT: delivery rider photo */}
      <Photo
        src="images/delivery.png"
        x={1010}
        y={120}
        w={810}
        h={534}
        at={C.delivery.fast - 3}
        radius={44}
        zoom={0.07}
        reverse
        from={{x: 220, y: 10, s: 0.96}}
        cfg={theme.spring.smooth}
        pos="55% 50%"
        float={5}
      />
      {/* brand chip on the photo corner (logo shown as supplied) */}
      <Photo
        src="images/logo.jpg"
        x={1660}
        y={540}
        w={190}
        h={190}
        at={C.delivery.home + 6}
        radius={95}
        border={8}
        zoom={0.04}
        cfg={theme.spring.bouncy}
        from={{y: 30, s: 0.5}}
        float={5}
      />
    </AbsoluteFill>
  );
};
