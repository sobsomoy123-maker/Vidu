import React from 'react';
import {AbsoluteFill, interpolate} from 'remotion';
import {C, PHONE, PHONE_BN} from '../choreo';
import {CL, FONT, MailIcon, Photo, PhoneIcon, PinIcon, Pill, Pop, useSince, useSp} from '../components/kit';
import {theme, withAlpha} from '../theme';

// Scene 6 - how to order + delivery zone (cues 7 + 8). Style: Glass cards + CTA.
// The phone number is NOT typed here: its digits come from the spoken digits in the SRT, each digit pops in when spoken.
export const Contact: React.FC = () => {
  const since = useSince();
  const sp = useSp();

  const zoneP = sp(since(C.contact.zone), theme.spring.smooth);
  const ringP = interpolate(since(C.contact.zone + 4), [0, 40], [0, 1], {easing: theme.ease.out, ...CL});

  return (
    <AbsoluteFill style={{fontFamily: FONT}}>
      {/* LEFT: page inbox card */}
      <Pop at={C.contact.page} y={44} x={-40} style={{position: 'absolute', left: 90, top: 150, width: 760, height: 250}}>
        <div style={cardStyle}>
          <div style={{width: 100, height: 100, borderRadius: 50, background: theme.colors.primary, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0}}>
            <MailIcon size={52} color={theme.colors.onPrimary} />
          </div>
          <div>
            <div style={{fontSize: 36, fontWeight: 600, color: theme.colors.textDim, lineHeight: 1.3}}>inbox করুন</div>
            <div style={{fontSize: 64, fontWeight: 700, color: theme.colors.text, lineHeight: 1.2, whiteSpace: 'nowrap'}}>আমাদের page-এ</div>
          </div>
        </div>
      </Pop>

      <Photo src="images/logo.jpg" x={1510} y={140} w={270} h={270} at={C.contact.page + 6} radius={135} border={8} zoom={0.04} cfg={theme.spring.bouncy} from={{y: 30, s: 0.6}} float={4} />

      {/* "অথবা" divider */}
      <Pop at={C.contact.call - 4} y={14} style={{position: 'absolute', left: 90, top: 414, width: 760, textAlign: 'center'}}>
        <div style={{fontSize: 44, fontWeight: 600, color: theme.colors.textDim, lineHeight: 1.3}}>অথবা</div>
      </Pop>

      {/* call card with spoken-digit number */}
      <Pop at={C.contact.call} y={44} x={-40} style={{position: 'absolute', left: 90, top: 484, width: 1740, height: 250}}>
        <div style={{...cardStyle, width: 1740, gap: 40}}>
          <div style={{width: 100, height: 100, borderRadius: 50, background: theme.colors.accent, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0}}>
            <PhoneIcon size={54} color={theme.colors.text} />
          </div>
          <div style={{flex: 1}}>
            <div style={{fontSize: 36, fontWeight: 600, color: theme.colors.textDim, lineHeight: 1.3}}>কল করুন</div>
            <div style={{display: 'flex', alignItems: 'center', height: 130}}>
              {PHONE.map((d, i) => {
                const p = sp(since(d.frame - 3), theme.spring.snappy);
                return (
                  <span
                    key={i}
                    style={{
                      display: 'inline-block',
                      width: i === 2 || i === 6 ? 74 : 66,
                      textAlign: 'center',
                      fontSize: 118,
                      fontWeight: 700,
                      lineHeight: 1.1,
                      letterSpacing: 0,
                      color: theme.colors.text,
                      fontVariantNumeric: 'tabular-nums',
                      opacity: Math.min(1, p * 2),
                      transform: `translateY(${(1 - p) * 30}px) scale(${0.8 + 0.2 * p})`,
                      marginRight: i === 4 ? 26 : 0,
                    }}
                  >
                    {PHONE_BN[i]}
                  </span>
                );
              })}
            </div>
          </div>
        </div>
      </Pop>

      {/* delivery zone */}
      <Pop at={C.contact.zone} y={44} style={{position: 'absolute', left: 90, top: 790, width: 1260, height: 190}}>
        <div style={{...cardStyle, height: 190, width: 1260, background: theme.colors.text, border: 'none', gap: 32}}>
          <div style={{position: 'relative', width: 110, height: 110, flexShrink: 0}}>
            <div
              style={{
                position: 'absolute',
                inset: 0,
                borderRadius: 55,
                border: `5px solid ${theme.colors.accent}`,
                opacity: ringP < 1 ? 1 - ringP : 0,
                transform: `scale(${0.4 + ringP * 1.2})`,
              }}
            />
            <div style={{position: 'absolute', left: 25, top: 18, transform: `scale(${zoneP})`, transformOrigin: '50% 100%'}}>
              <PinIcon size={60} color={theme.colors.accent} dot={theme.colors.text} />
            </div>
          </div>
          <div>
            <div style={{fontSize: 74, fontWeight: 700, lineHeight: 1.2, color: theme.colors.onDark, whiteSpace: 'nowrap'}}>হবিগঞ্জ পৌরসভার ভেতরে</div>
            <div style={{fontSize: 40, fontWeight: 500, lineHeight: 1.3, color: withAlpha(theme.colors.onDark, 0.78), whiteSpace: 'nowrap'}}>home delivery</div>
          </div>
        </div>
      </Pop>

      {/* ইনশাআল্লাহ badge */}
      <Pop at={C.contact.inshaAllah} y={26} s={0.8} cfg={theme.spring.bouncy} style={{position: 'absolute', left: 1400, top: 828}}>
        <Pill text="ইনশাআল্লাহ" size={64} padX={44} padY={8} bg={theme.colors.accent} color={theme.colors.text} weight={700} />
      </Pop>
    </AbsoluteFill>
  );
};

const cardStyle: React.CSSProperties = {
  height: 250,
  width: 760,
  borderRadius: theme.radius.card,
  display: 'flex',
  alignItems: 'center',
  gap: 32,
  padding: '0 44px',
  boxSizing: 'border-box',
  background: withAlpha(theme.colors.surface, 0.82),
  border: `2px solid ${withAlpha(theme.colors.surface, 0.95)}`,
  boxShadow: theme.shadow.card,
};
