import React, {createContext, useContext} from 'react';
import {AbsoluteFill, Img, interpolate, spring, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {theme, withAlpha} from '../theme';

/* ------------------------------------------------------------------ */
/* scene time helpers                                                  */
/* ------------------------------------------------------------------ */

const SceneCtx = createContext<{start: number}>({start: 0});
export const SceneProvider = SceneCtx.Provider;

/** since(g) = frames elapsed since ABSOLUTE frame g (negative before it happens) */
export const useSince = () => {
  const frame = useCurrentFrame();
  const {start} = useContext(SceneCtx);
  return (g: number) => frame - (g - start);
};

type SpringCfg = {damping: number; stiffness: number; mass: number};

/** spring(f) with a safe 0 before the start */
export const useSp = () => {
  const {fps} = useVideoConfig();
  return (f: number, cfg: SpringCfg = theme.spring.smooth) => (f <= 0 ? 0 : spring({frame: f, fps, config: cfg}));
};

export const CL = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;

export const FONT = theme.fonts.main;

/* ------------------------------------------------------------------ */
/* Pop: premium entrance (opacity + rise + scale) and a fast exit      */
/* ------------------------------------------------------------------ */

export const Pop: React.FC<{
  at: number;
  out?: number;
  y?: number;
  x?: number;
  s?: number;
  cfg?: SpringCfg;
  origin?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}> = ({at, out, y = 40, x = 0, s = 0.94, cfg = theme.spring.smooth, origin, style, children}) => {
  const sp = useSp();
  const since = useSince();
  const p = sp(since(at), cfg);
  const o = interpolate(p, [0, 0.55], [0, 1], CL);
  const q =
    out === undefined
      ? 0
      : interpolate(since(out), [0, theme.motion.exitFrames], [0, 1], {easing: theme.ease.in, ...CL});
  const tx = x * (1 - p);
  const ty = y * (1 - p) - 30 * q;
  const sc = (s + (1 - s) * p) * (1 - 0.05 * q);
  return (
    <div
      style={{
        ...style,
        opacity: o * (1 - q),
        transform: `translate(${tx}px, ${ty}px) scale(${sc})`,
        transformOrigin: origin ?? 'center center',
      }}
    >
      {children}
    </div>
  );
};

/* ------------------------------------------------------------------ */
/* Words: word-by-word staggered reveal. Splits on spaces ONLY (never  */
/* on letters) so Bengali conjuncts / kar marks never break.           */
/* ------------------------------------------------------------------ */

export type WordSpec = string | {t: string; color?: string; sweep?: boolean};

export const Words: React.FC<{
  words: WordSpec[];
  at: number;
  out?: number;
  per?: number;
  size: number;
  weight?: number;
  color?: string;
  gap?: number;
  lh?: number;
  align?: 'flex-start' | 'center' | 'flex-end';
  style?: React.CSSProperties;
}> = ({words, at, out, per = 4, size, weight = 700, color = theme.colors.text, gap = 24, lh = 1.28, align = 'flex-start', style}) => {
  const sp = useSp();
  const since = useSince();
  const q =
    out === undefined
      ? 0
      : interpolate(since(out), [0, theme.motion.exitFrames], [0, 1], {easing: theme.ease.in, ...CL});
  return (
    <div
      style={{
        display: 'flex',
        flexWrap: 'wrap',
        columnGap: gap,
        rowGap: 0,
        justifyContent: align,
        fontFamily: FONT,
        fontSize: size,
        fontWeight: weight,
        lineHeight: lh,
        letterSpacing: 0,
        color,
        opacity: 1 - q,
        transform: `translateY(${-26 * q}px)`,
        ...style,
      }}
    >
      {words.map((w, i) => {
        const spec = typeof w === 'string' ? {t: w} : w;
        const p = sp(since(at + i * per), theme.spring.snappy);
        const o = interpolate(p, [0, 0.5], [0, 1], CL);
        const sw = spec.sweep ? interpolate(since(at + i * per + 8), [0, 16], [0, 100], {easing: theme.ease.out, ...CL}) : 0;
        return (
          <span
            key={i}
            style={{
              position: 'relative',
              display: 'inline-block',
              whiteSpace: 'nowrap',
              color: spec.color ?? color,
              opacity: o,
              transform: `translateY(${(1 - p) * 34}px) scale(${0.9 + 0.1 * p})`,
              transformOrigin: '50% 80%',
            }}
          >
            {spec.sweep ? (
              <span
                style={{
                  position: 'absolute',
                  left: -8,
                  top: '14%',
                  bottom: '8%',
                  width: `calc(${sw}% + ${sw / 100 * 16}px)`,
                  background: withAlpha(theme.colors.accent, 0.5),
                  borderRadius: size * 0.2,
                  zIndex: 0,
                }}
              />
            ) : null}
            <span style={{position: 'relative', zIndex: 1}}>{spec.t}</span>
          </span>
        );
      })}
    </div>
  );
};

/* ------------------------------------------------------------------ */
/* Photo: rounded card with Ken Burns (every still gets slow motion)   */
/* ------------------------------------------------------------------ */

export const Photo: React.FC<{
  src: string;
  x: number;
  y: number;
  w: number;
  h: number;
  at: number;
  out?: number;
  radius?: number;
  border?: number;
  zoom?: number;
  reverse?: boolean;
  pos?: string;
  fit?: 'cover' | 'contain';
  rot?: number;
  from?: {x?: number; y?: number; s?: number};
  cfg?: SpringCfg;
  float?: number;
  children?: React.ReactNode;
  shadow?: boolean;
  bg?: string;
}> = ({
  src, x, y, w, h, at, out, radius = theme.radius.card, border = 0, zoom = 0.08, reverse = false, pos = '50% 50%',
  fit = 'cover', rot = 0, from, cfg = theme.spring.smooth, float = 4, children, shadow = true, bg,
}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const dur = fps * 12;
  const k = interpolate(frame, [0, dur], reverse ? [1 + zoom, 1] : [1, 1 + zoom], {easing: theme.ease.inOut, ...CL});
  const pan = interpolate(frame, [0, dur], reverse ? [12, -12] : [-12, 12], {easing: theme.ease.inOut, ...CL});
  const bob = Math.sin(frame / 34 + x) * float;
  return (
    <Pop
      at={at}
      out={out}
      y={from?.y ?? 50}
      x={from?.x ?? 0}
      s={from?.s ?? 0.92}
      cfg={cfg}
      style={{position: 'absolute', left: x, top: y + bob, width: w, height: h}}
    >
      <div
        style={{
          width: w,
          height: h,
          borderRadius: radius,
          overflow: 'hidden',
          position: 'relative',
          transform: `rotate(${rot}deg)`,
          boxShadow: shadow ? theme.shadow.card : 'none',
          border: border ? `${border}px solid ${theme.colors.surface}` : 'none',
          boxSizing: 'border-box',
          background: bg ?? theme.colors.surface,
        }}
      >
        <Img
          src={staticFile(src)}
          style={{
            width: '100%',
            height: '100%',
            objectFit: fit,
            objectPosition: pos,
            transform: `scale(${k}) translateX(${pan}px)`,
          }}
        />
        {children}
      </div>
    </Pop>
  );
};

/* ------------------------------------------------------------------ */
/* small UI pieces                                                     */
/* ------------------------------------------------------------------ */

export const Pill: React.FC<{
  text: string;
  size?: number;
  bg?: string;
  color?: string;
  padX?: number;
  padY?: number;
  weight?: number;
  style?: React.CSSProperties;
}> = ({text, size = 44, bg = theme.colors.text, color = theme.colors.onDark, padX = 34, padY = 8, weight = 600, style}) => (
  <div
    style={{
      display: 'inline-block',
      fontFamily: FONT,
      fontSize: size,
      fontWeight: weight,
      lineHeight: 1.3,
      letterSpacing: 0,
      padding: `${padY}px ${padX}px`,
      borderRadius: theme.radius.pill,
      background: bg,
      color,
      whiteSpace: 'nowrap',
      ...style,
    }}
  >
    {text}
  </div>
);

/** animated check mark in a circle. `p` = 0..1 draw progress */
export const Tick: React.FC<{size: number; p: number; bg?: string; color?: string}> = ({size, p, bg = theme.colors.accent, color = theme.colors.text}) => (
  <svg width={size} height={size} viewBox="0 0 48 48" style={{display: 'block', transform: `scale(${0.7 + 0.3 * Math.min(1, p * 1.4)})`}}>
    <circle cx="24" cy="24" r="23" fill={bg} opacity={Math.min(1, p * 2)} />
    <path
      d="M13 25.5 L21 33 L35.5 16"
      fill="none"
      stroke={color}
      strokeWidth="5.5"
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeDasharray="40"
      strokeDashoffset={40 * (1 - Math.max(0, Math.min(1, (p - 0.25) / 0.75)))}
    />
  </svg>
);

export const PinIcon: React.FC<{size: number; color?: string; dot?: string}> = ({size, color = theme.colors.text, dot = theme.colors.bg}) => (
  <svg width={size} height={size} viewBox="0 0 32 32" style={{display: 'block'}}>
    <path d="M16 2C10.5 2 6 6.4 6 11.9 6 19.3 16 30 16 30s10-10.7 10-18.1C26 6.4 21.5 2 16 2z" fill={color} />
    <circle cx="16" cy="12" r="4.2" fill={dot} />
  </svg>
);

export const PhoneIcon: React.FC<{size: number; color?: string}> = ({size, color = theme.colors.text}) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{display: 'block'}}>
    <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" />
  </svg>
);

export const MailIcon: React.FC<{size: number; color?: string}> = ({size, color = theme.colors.text}) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{display: 'block'}}>
    <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" />
    <polyline points="22,6 12,13 2,6" />
  </svg>
);

export const CursorIcon: React.FC<{size: number}> = ({size}) => (
  <svg width={size} height={size} viewBox="0 0 24 28" style={{display: 'block', filter: 'drop-shadow(0 4px 6px rgba(59,31,20,0.35))'}}>
    <path d="M3 2 L3 21 L8 16.6 L11.6 24.6 L15 23.1 L11.5 15.4 L18.5 15.4 Z" fill={theme.colors.surface} stroke={theme.colors.text} strokeWidth="1.8" strokeLinejoin="round" />
  </svg>
);

/* ------------------------------------------------------------------ */
/* layer stack: mesh (bottom) ... grade, grain, vignette (top)         */
/* ------------------------------------------------------------------ */

export const BgMesh: React.FC = () => {
  const frame = useCurrentFrame();
  const d1 = Math.sin(frame / 55) * 60;
  const d2 = Math.cos(frame / 70) * 46;
  const d3 = Math.sin(frame / 80 + 1) * 40;
  return (
    <AbsoluteFill style={{background: `linear-gradient(160deg, ${theme.colors.bg} 0%, ${theme.colors.bgAlt} 100%)`}}>
      <div style={{position: 'absolute', width: 1300, height: 1300, borderRadius: '50%', top: -560, left: -380 + d1, filter: 'blur(60px)', background: `radial-gradient(circle, ${withAlpha(theme.colors.accent, 0.3)}, transparent 62%)`}} />
      <div style={{position: 'absolute', width: 1100, height: 1100, borderRadius: '50%', bottom: -520, right: -300 - d2, filter: 'blur(70px)', background: `radial-gradient(circle, ${withAlpha(theme.colors.primary, 0.16)}, transparent 65%)`}} />
      <div style={{position: 'absolute', width: 800, height: 800, borderRadius: '50%', top: 300 + d3, right: 520, filter: 'blur(80px)', background: `radial-gradient(circle, ${withAlpha(theme.colors.accent, 0.14)}, transparent 66%)`}} />
    </AbsoluteFill>
  );
};

export const Grade: React.FC = () => (
  <AbsoluteFill style={{pointerEvents: 'none'}}>
    <AbsoluteFill style={{backgroundColor: theme.colors.primary, mixBlendMode: 'soft-light', opacity: 0.1}} />
    <AbsoluteFill
      style={{background: 'linear-gradient(180deg, rgba(59,31,20,0.06), transparent 26%, transparent 74%, rgba(59,31,20,0.1))'}}
    />
  </AbsoluteFill>
);

export const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const noise = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='220' height='220'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2'/%3E%3C/filter%3E%3Crect width='220' height='220' filter='url(%23n)' opacity='0.5'/%3E%3C/svg%3E")`;
  return (
    <AbsoluteFill
      style={{
        pointerEvents: 'none',
        backgroundImage: noise,
        backgroundSize: '220px',
        backgroundPosition: `${(frame * 7) % 220}px ${(frame * 13) % 220}px`,
        opacity: 0.05,
        mixBlendMode: 'multiply',
      }}
    />
  );
};

export const Vignette: React.FC = () => (
  <AbsoluteFill
    style={{pointerEvents: 'none', background: `radial-gradient(ellipse at center, transparent 58%, ${theme.colors.vignette} 100%)`}}
  />
);
