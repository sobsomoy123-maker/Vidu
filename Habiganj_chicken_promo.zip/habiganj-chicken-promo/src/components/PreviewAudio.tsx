import React, {useEffect, useState} from 'react';
import {Audio, continueRender, delayRender, getRemotionEnvironment, staticFile} from 'remotion';
import {PREVIEW_VOICEOVER, VOICEOVER_IN_RENDER} from '../config';

// Plays public/voiceover.mp3 if it exists (silently skipped otherwise). Studio preview only, unless VOICEOVER_IN_RENDER.
export const PreviewAudio: React.FC = () => {
  const {isRendering} = getRemotionEnvironment();
  const enabled = PREVIEW_VOICEOVER && (!isRendering || VOICEOVER_IN_RENDER);
  const [ok, setOk] = useState(false);

  useEffect(() => {
    if (!enabled) return;
    const h = delayRender('check voiceover.mp3');
    fetch(staticFile('voiceover.mp3'), {method: 'HEAD'})
      .then((r) => setOk(r.ok && (r.headers.get('content-type') ?? '').includes('audio')))
      .catch(() => setOk(false))
      .finally(() => continueRender(h));
  }, [enabled]);

  return enabled && ok ? <Audio src={staticFile('voiceover.mp3')} volume={1} /> : null;
};
