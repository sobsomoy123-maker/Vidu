// Scene boundaries = cue boundaries (a scene can span several cues).
// A new scene starts `lead` frames BEFORE its first cue so the visual is already arriving when the words start.
import {cueStartFrame, TOTAL_FRAMES} from './timing';
import {theme} from './theme';

export type Dir = 'left' | 'right' | 'up' | 'down'; // side the new scene pushes in FROM

export const SCENE_DEFS = [
  {id: 'hook', cues: [1], lead: 0, from: 'right'},
  {id: 'click', cues: [2], lead: 6, from: 'right'},
  {id: 'cuts', cues: [3, 4], lead: 6, from: 'down'},
  {id: 'offal', cues: [5], lead: 14, from: 'left'},
  {id: 'delivery', cues: [6], lead: 6, from: 'right'},
  {id: 'contact', cues: [7, 8], lead: 6, from: 'down'},
  {id: 'recap', cues: [9], lead: 12, from: 'right'},
] as const;

export type SceneId = (typeof SCENE_DEFS)[number]['id'];

const P = theme.motion.pushFrames;

export const SCENES = SCENE_DEFS.map((d, i) => {
  const start = i === 0 ? 0 : cueStartFrame(d.cues[0]) - d.lead;
  return {...d, start};
}).map((s, i, arr) => {
  // the previous scene stays for `P` frames after the next one starts (push transition overlap)
  const end = i < arr.length - 1 ? arr[i + 1].start + P : TOTAL_FRAMES;
  return {...s, end, dur: end - s.start};
});

export const sceneStart = (id: SceneId) => SCENES.find((s) => s.id === id)!.start;
