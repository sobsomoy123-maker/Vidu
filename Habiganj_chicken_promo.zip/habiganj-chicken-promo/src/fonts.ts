// Offline fonts: Hind Siliguri comes from the @fontsource package (installed by `npm install`),
// so nothing is fetched from the internet at preview or render time.
import '@fontsource/hind-siliguri/500.css';
import '@fontsource/hind-siliguri/600.css';
import '@fontsource/hind-siliguri/700.css';
import {continueRender, delayRender} from 'remotion';

const handle = delayRender('Loading Hind Siliguri');
const done = () => {
  try {
    continueRender(handle);
  } catch {
    /* already continued */
  }
};

if (typeof document !== 'undefined' && document.fonts) {
  Promise.all([
    document.fonts.load('700 64px "Hind Siliguri"', 'আজই অর্ডার Fresh Chicken ০১২৩৪৫৬৭৮৯'),
    document.fonts.load('600 64px "Hind Siliguri"', 'আজই অর্ডার Fresh Chicken ০১২৩৪৫৬৭৮৯'),
    document.fonts.load('500 64px "Hind Siliguri"', 'আজই অর্ডার Fresh Chicken ০১২৩৪৫৬৭৮৯'),
  ])
    .then(done)
    .catch(done);
} else {
  done();
}
