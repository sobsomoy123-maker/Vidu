// theme.ts - single source of truth: colors, fonts, radius, shadows, easings, spring presets.
// Color scheme: "Ammu's Warm Kitchen" (warm light, taken from the Ammu's Kitchen logo).
import {Easing} from 'remotion';

export const theme = {
  colors: {
    bg: '#FFF7EC',
    bgAlt: '#F9E8CF',
    surface: '#FFFFFF',
    primary: '#B3261E', // THE hero color - at most one hero element per frame
    accent: '#F08A24',
    text: '#3B1F14',
    textDim: '#85654F',
    onDark: '#FFF7EC',
    onPrimary: '#FFFFFF',
    hairline: 'rgba(59, 31, 20, 0.12)',
    scrim: 'rgba(59, 31, 20, 0.50)',
    vignette: 'rgba(59, 31, 20, 0.16)',
    glow: 'rgba(179, 38, 30, 0.38)',
  },
  fonts: {
    // Hind Siliguri is bundled through the @fontsource/hind-siliguri package (see fonts.ts) -> works offline.
    main: "'Hind Siliguri', 'Noto Sans Bengali', 'Nirmala UI', Vrinda, sans-serif",
  },
  radius: {card: 36, small: 22, pill: 999},
  shadow: {
    card: '0 38px 70px -26px rgba(59, 31, 20, 0.42), 0 10px 22px -10px rgba(59, 31, 20, 0.2)',
    soft: '0 18px 36px -18px rgba(59, 31, 20, 0.35)',
  },
  // THE easing curves. Linear is never used.
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1), // entrances
    inOut: Easing.bezier(0.83, 0, 0.17, 1), // moves, Ken Burns, scene push
    in: Easing.bezier(0.7, 0, 0.84, 0), // exits only
  },
  spring: {
    snappy: {damping: 14, stiffness: 160, mass: 0.6}, // words, small pops
    smooth: {damping: 20, stiffness: 90, mass: 1}, // big elements
    bouncy: {damping: 11, stiffness: 170, mass: 0.7}, // logo, pin, accents
  },
  motion: {
    // visuals land this many frames BEFORE the matching spoken words
    ahead: 5,
    exitFrames: 10,
    pushFrames: 12,
  },
} as const;

/** "#RRGGBB" + alpha 0..1  ->  "#RRGGBBAA" */
export const withAlpha = (hex: string, a: number): string =>
  hex + Math.round(Math.max(0, Math.min(1, a)) * 255).toString(16).padStart(2, '0');
