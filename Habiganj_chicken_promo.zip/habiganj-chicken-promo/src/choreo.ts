// Choreography: every on-screen beat and every sound is a global frame derived from the SRT.
import {readDigitSequence, say, sayEnd, toBn, vis} from './timing';
import {SCENES} from './timeline';

const sc = (id: string) => SCENES.find((s) => s.id === id)!;

// phone number = the spoken digit words in the script ("শূন্য এক আট ... সাত" + "এক এক")
export const PHONE = readDigitSequence('শূন্য', 11, 'কল করুন');
export const PHONE_TEXT = PHONE.map((d) => d.digit).join('');
export const PHONE_BN = toBn(PHONE_TEXT);

export const C = {
  hook: {
    logo: 1,
    disc: 12,
    pill: vis('হবিগঞ্জ'),
    fresh: vis('Fresh Chicken'),
    chicken: vis('Chicken'),
    sub: vis('কার্যক্রম'),
  },
  click: {
    window: sc('click').start + 2,
    cut: vis('Chicken cut'),
    one: vis('এক ক্লিকেই'),
    click: say('ক্লিকেই') + 8, // the click lands just as the word finishes
    reach: vis('হাতের নাগালে'),
    boneless: vis('Super fresh boneless'),
  },
  cuts: {
    start: sc('cuts').start + 2,
    boneless: sc('cuts').start + 2, // already spoken at the end of the previous cue
    leg: vis('juicy leg piece'),
    thigh: vis('soft thigh piece'),
    wings: vis('crispy chicken wings'),
    end: vis('এছাড়াও পাচ্ছেন'),
  },
  offal: {
    kicker: vis('পরিষ্কার পরিচ্ছন্ন'),
    gizzard: vis('গিলা'),
    liver: vis('কলিজা'),
    packet: vis('আলাদা প্যাকেটে'),
    processed: vis('পরিচ্ছন্নভাবে process করা Chicken'),
    ready: vis('ready to cook cut'),
  },
  delivery: {
    fast: vis('দ্রুত'),
    home: vis('home delivery'),
    late: vis('তাহলে আর দেরি কেন'),
    today: vis('আজই অর্ডার'),
    inbox: vis('inbox'),
  },
  contact: {
    page: vis('করুন আমাদের'),
    call: vis('অথবা কল করুন'),
    number: vis('নম্বরে'),
    zone: vis('হবিগঞ্জ পৌরসভার ভেতরে'),
    home: vis('home delivery', 1),
    inshaAllah: vis('ইনশাআল্লাহ'),
  },
  recap: {
    taste: vis('স্বাদ'),
    fresh: vis('সতেজতা'),
    easy: vis('সুবিধা সব'),
    together: vis('সব একসাথে'),
    final: vis('আপনার অর্ডারের'),
    waiting: vis('অপেক্ষায়'),
    we: vis('আমরা'),
  },
};

// ---- sound plan (global frames). Few sounds, only on main entrances / logo / cards / transitions ----
export type Sfx = {frame: number; name: 'pop' | 'click' | 'whoosh' | 'chime' | 'thud'; vol: number; rate?: number};

const V = {pop: 0.3, click: 0.28, whoosh: 0.26, chime: 0.3, thud: 0.3};
let n = 0;
const vary = () => 0.96 + ((n++ * 37) % 9) * 0.01; // small pitch variation between repeats (0.96 - 1.04)
const s = (frame: number, name: Sfx['name'], rate?: number): Sfx => ({
  frame: Math.max(0, Math.round(frame)),
  name,
  vol: V[name],
  rate: rate ?? vary(),
});

export const SFX: Sfx[] = [
  // hook
  s(C.hook.logo + 3, 'chime', 1),
  s(C.hook.pill, 'pop'),
  s(C.hook.fresh, 'thud', 1),
  // click scene
  s(C.click.click, 'click'),
  s(C.click.boneless, 'pop'),
  // cuts: each item activates with a crisp click
  s(C.cuts.boneless + 6, 'click'),
  s(C.cuts.leg, 'click'),
  s(C.cuts.thigh, 'click'),
  s(C.cuts.wings, 'click'),
  // offal / process
  s(C.offal.gizzard, 'pop'),
  s(C.offal.liver, 'pop'),
  s(C.offal.processed, 'click'),
  s(C.offal.ready, 'click'),
  // delivery
  s(C.delivery.fast, 'thud', 1),
  s(C.delivery.inbox + 14, 'click'),
  // contact
  s(C.contact.page, 'pop'),
  s(C.contact.call, 'pop'),
  s(C.contact.zone + 8, 'pop'),
  s(C.contact.home, 'pop'),
  // recap
  s(C.recap.taste, 'pop'),
  s(C.recap.fresh, 'pop'),
  s(C.recap.easy, 'pop'),
  s(C.recap.final + 4, 'chime', 1),
  // scene transitions: one soft whoosh each
  ...SCENES.slice(1).map((sceneDef) => s(sceneDef.start + 1, 'whoosh')),
];

export {say, sayEnd};
