// Global switches.
export const FPS = 30;
export const WIDTH = 1920;
export const HEIGHT = 1080;

// Voiceover preview (public/voiceover.mp3): plays in Remotion Studio only, to check sync.
// If the file is missing it is silently skipped. Set to false to mute it in Studio too.
export const PREVIEW_VOICEOVER = true;
// Default OFF in renders: the exported MP4 carries SFX only. Set true if you want the voiceover baked in.
export const VOICEOVER_IN_RENDER = false;

export const SFX_ENABLED = true;
