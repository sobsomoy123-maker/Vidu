// All timing comes from the SRT (via cues.generated.ts). Nothing is placed by hand.
// The SRT only has cue-level times, so a phrase inside a cue is located proportionally by its
// character position between the cue's start and end (TTS speaks at a fairly even pace).
import {CUES} from './cues.generated';
import {FPS} from './config';
import {theme} from './theme';

const clean = (s: string) => s.replace(/\s+/g, ' ').trim();

type Seg = {off: number; len: number; startMs: number; endMs: number};
const segs: Seg[] = [];
let script = '';
CUES.forEach((c, i) => {
  const t = clean(c.text);
  if (i > 0) script += ' ';
  segs.push({off: script.length, len: t.length, startMs: c.startMs, endMs: c.endMs});
  script += t;
});

export const SCRIPT = script;
export const TOTAL_FRAMES = Math.ceil((CUES[CUES.length - 1].endMs / 1000) * FPS);

const msAt = (idx: number): number => {
  const s = segs.find((g) => idx >= g.off && idx < g.off + g.len + 1) ?? segs[segs.length - 1];
  const frac = Math.min(1, Math.max(0, (idx - s.off) / Math.max(1, s.len)));
  return s.startMs + frac * (s.endMs - s.startMs);
};

export const msToFrame = (ms: number) => Math.round((ms / 1000) * FPS);
export const cueStartFrame = (n: number) => msToFrame(CUES[n - 1].startMs);
export const cueEndFrame = (n: number) => msToFrame(CUES[n - 1].endMs);

const indexOfNth = (phrase: string, nth: number): number => {
  let from = 0;
  let idx = -1;
  for (let k = 0; k <= nth; k++) {
    idx = script.indexOf(phrase, from);
    if (idx < 0) throw new Error(`timing: phrase not found in SRT -> "${phrase}" (occurrence ${nth})`);
    from = idx + 1;
  }
  return idx;
};

/** frame (absolute, whole video) at which `phrase` starts being spoken */
export const say = (phrase: string, nth = 0): number => msToFrame(msAt(indexOfNth(phrase, nth)));
/** frame at which `phrase` has been spoken */
export const sayEnd = (phrase: string, nth = 0): number =>
  msToFrame(msAt(indexOfNth(phrase, nth) + phrase.length));
/** visuals land a few frames BEFORE the spoken words */
export const vis = (phrase: string, nth = 0): number => Math.max(0, say(phrase, nth) - theme.motion.ahead);

/** Spoken digit words -> digit frames (derived from the script, not typed in). */
const DIGIT_WORDS: Record<string, string> = {
  'শূন্য': '0',
  'এক': '1',
  'দুই': '2',
  'তিন': '3',
  'চার': '4',
  'পাঁচ': '5',
  'ছয়': '6',
  'সাত': '7',
  'আট': '8',
  'নয়': '9',
};
const BN_DIGITS = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
export const toBn = (s: string) => s.replace(/[0-9]/g, (d) => BN_DIGITS[Number(d)]);

export const readDigitSequence = (firstWord: string, count: number, afterPhrase: string) => {
  // collect `count` digit words starting at the first occurrence of `firstWord` after `afterPhrase`
  let pos = indexOfNth(afterPhrase, 0) + afterPhrase.length;
  pos = script.indexOf(firstWord, pos);
  const digits: {digit: string; frame: number}[] = [];
  while (digits.length < count && pos >= 0 && pos < script.length) {
    const rest = script.slice(pos);
    const m = rest.match(/^\S+/);
    if (!m) break;
    const word = m[0];
    if (word in DIGIT_WORDS) digits.push({digit: DIGIT_WORDS[word], frame: msToFrame(msAt(pos))});
    pos += word.length + 1;
  }
  return digits;
};
